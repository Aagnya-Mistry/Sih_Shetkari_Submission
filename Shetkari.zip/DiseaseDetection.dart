import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io'; // To work with file paths

class Diseasedetection extends StatefulWidget {
  const Diseasedetection({Key? key}) : super(key: key);

  @override
  _DiseasedetectionState createState() => _DiseasedetectionState();
}

class _DiseasedetectionState extends State<Diseasedetection> {
  File? _imageFile; // To store the selected image
  final ImagePicker _picker = ImagePicker();
  bool _showTextField = false; // To control the visibility of the TextField
  String _diseaseInfo =
      "LEMON CROTON \nLemon croton, a fungal disease affecting various crops, can be managed with fungicides like Thiophanate-methyl or Chlorothalonil. These fungicides help control fungal growth and prevent further spread. Ensure proper plant spacing and airflow around the plants to minimize moisture buildup. Maintain proper soil drainage to prevent waterlogging, which favors fungal growth. Regularly inspect the plants and remove infected leaves or branches. Proper sanitation practices, such as cleaning tools and equipment after use, can prevent the spread of the fungus. Avoid planting crops in areas where lemon croton has previously been an issue to reduce recurrence.";

  // Function to pick an image from the camera
  Future<void> _pickImageFromCamera() async {
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  // Function to pick an image from the gallery
  Future<void> _pickImageFromGallery() async {
    final XFile? pickedFile =
        await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  // Function to toggle the visibility of the TextField
  void _toggleTextField() {
    setState(() {
      _showTextField = true; // When submit button is clicked, show the text
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Disease Detection',
          style: TextStyle(
              color: Colors.black,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              fontFamily: "Merriweather"),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // Display the image if it's selected
              if (_imageFile != null) ...[
                Image.file(_imageFile!,
                    height: 250, width: 250, fit: BoxFit.cover),
                const SizedBox(height: 20),
              ],
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Button to pick image from camera
                  ElevatedButton(
                    onPressed: _pickImageFromCamera,
                    child: const Text('Pick from Camera'),
                  ),
                  const SizedBox(width: 20),
                  // Button to pick image from gallery
                  ElevatedButton(
                    onPressed: _pickImageFromGallery,
                    child: const Text('Pick from Gallery'),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              // Button to show the TextField
              ElevatedButton(
                onPressed: _toggleTextField,
                child: const Text('Submit'),
              ),
              const SizedBox(height: 20),
              // Display the disease info text if _showTextField is true
              if (_showTextField)
                Text(
                  _diseaseInfo,
                  style: TextStyle(
                      fontFamily: 'Mergeone',
                      fontSize: 14,
                      color: Colors.black),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
