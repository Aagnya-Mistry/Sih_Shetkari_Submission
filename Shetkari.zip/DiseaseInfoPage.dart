import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:http/http.dart' as http;

class Diseaseinfopage extends StatefulWidget {
  const Diseaseinfopage();

  @override
  State<Diseaseinfopage> createState() => _DiseaseinfopageState();
}

class _DiseaseinfopageState extends State<Diseaseinfopage> {
  File? _image;
  String? _hpiImagePath;
  String? _healthGrade;
  double? _averageHpi;
  bool _isLoading = false;

  // Replace with your system's IP address
  static const String baseUrl = 'http://192.168.187.59:5000';

  Future<void> _pickImage() async {
    final ImagePicker picker = ImagePicker();

    // Ask user whether they want to take a picture or choose from the gallery
    final selectedSource = await showDialog<ImageSource>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Choose Image Source'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(ImageSource.camera),
            child: const Text('Camera'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(ImageSource.gallery),
            child: const Text('Gallery'),
          ),
        ],
      ),
    );

    if (selectedSource != null) {
      final XFile? image = await picker.pickImage(source: selectedSource);

      if (image != null) {
        setState(() {
          _image = File(image.path);
          _hpiImagePath = null;
          _healthGrade = null;
          _averageHpi = null;
        });
        await _uploadImage();
      }
    }
  }

  Future<void> _uploadImage() async {
    if (_image == null) return;

    setState(() {
      _isLoading = true;
    });

    try {
      // Create multipart request
      var request = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload'));

      // Add file to request
      request.files.add(await http.MultipartFile.fromPath(
        'file',
        _image!.path,
      ));

      // Send request
      var response = await request.send();
      var responseData = await response.stream.bytesToString();
      var jsonResponse = json.decode(responseData);

      if (response.statusCode == 200) {
        setState(() {
          _hpiImagePath = '$baseUrl/${jsonResponse['HPI Image Path']}';
          _healthGrade = jsonResponse['Health Grade'];
          _averageHpi = jsonResponse['Average HPI'].toDouble();
        });
      } else {
        throw Exception('Failed to upload image');
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey.withOpacity(0.5),
        title: Center(
          child: Text(
            "NDIV Index Analyzer",
            style: TextStyle(
              color: Colors.black,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              fontFamily: "Merriweather",
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: _pickImage,
              child: const Text('Select Image'),
            ),
            const SizedBox(height: 16),
            if (_image != null) ...[
              const Text('Selected Image:',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Image.file(_image!),
              const SizedBox(height: 16),
            ],
            if (_isLoading) const Center(child: CircularProgressIndicator()),
            if (_hpiImagePath != null) ...[
              const Text('NDIV Analysis Result:',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Image.network(_hpiImagePath!),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Health Grade: $_healthGrade',
                          style: const TextStyle(fontSize: 18)),
                      const SizedBox(height: 8),
                      Text('Average HPI: ${_averageHpi?.toStringAsFixed(2)}%',
                          style: const TextStyle(fontSize: 18)),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

    // @override
    // Widget build(BuildContext context) {
    //   final localizations = AppLocalizations.of(context);
    //   if (localizations == null) {
    //     return Text('Localization not available'); // Fallback text
    //   }
    //   return Scaffold(
    //     appBar: AppBar(
    //       backgroundColor: Colors.grey.withOpacity(0.5),
    //       leading: IconButton(
    //         icon: const Icon(Icons.arrow_back, color: Colors.black),
    //         onPressed: () => Navigator.pop(context),
    //       ),
    //       title: Center(
    //         child: Text(
    //           localizations.page2,
    //           style: TextStyle(
    //               color: Colors.black,
    //               fontSize: 20,
    //               fontWeight: FontWeight.bold,
    //               fontFamily: "Merriweather"),
    //         ),
    //       ),
    //       actions: [
    //         IconButton(
    //           icon: const Icon(Icons.bookmark_border, color: Colors.black),
    //           onPressed: () {
    //             // Add bookmark functionality here
    //           },
    //         ),
    //       ],
    //     ),
    //     body: SingleChildScrollView(
    //       scrollDirection: Axis.vertical,
    //       child: Padding(
    //         padding: const EdgeInsets.only(left: 10, right: 10),
    //         child: Column(
    //           crossAxisAlignment: CrossAxisAlignment.start,
    //           children: [
    //             const SizedBox(height: 10),
    //             Text(
    //               "Disease Detection",
    //               style: const TextStyle(
    //                   fontFamily: "Merriweather",
    //                   fontSize: 30,
    //                   fontWeight: FontWeight.bold),
    //             ),
    //             const SizedBox(height: 10),
    //             Center(
    //               child: Container(
    //                 width: 250,
    //                 height: 250,
    //                 decoration: BoxDecoration(
    //                   color: Colors.grey.withOpacity(0.5),
    //                   borderRadius: BorderRadius.circular(50),
    //                   boxShadow: const [
    //                     BoxShadow(
    //                         color: Colors.black,
    //                         blurRadius: 12,
    //                         offset: Offset(0, 2))
    //                   ],
    //                 ),
    //                 clipBehavior: Clip.hardEdge,
    //                 child: Image.asset(
    //                   "assets/images/default.jpeg",
    //                   fit: BoxFit.fill,
    //                 ),
    //               ),
    //             ),
    //             const SizedBox(height: 10),
    //             const Divider(),
    //             const Text(
    //               "About the Disease",
    //               style: TextStyle(
    //                 fontFamily: "Merriweather",
    //                 fontSize: 22,
    //                 fontWeight: FontWeight.bold,
    //               ),
    //             ),
    //             const Text(
    //               "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet urna vel sapien cursus pharetra a sed justo. Curabitur tincidunt augue at efficitur varius.",
    //               style: TextStyle(fontFamily: "Mergeone", fontSize: 14),
    //             ),
    //             const SizedBox(height: 10),
    //             const Text(
    //               "What Caused it?",
    //               style: TextStyle(
    //                   fontFamily: "Merriweather",
    //                   fontSize: 22,
    //                   fontWeight: FontWeight.bold),
    //             ),
    //             const Text(
    //               "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sit amet urna vel sapien cursus pharetra a sed justo. Curabitur tincidunt augue at efficitur varius.",
    //               style: TextStyle(fontFamily: "Mergeone", fontSize: 14),
    //             ),
    //             const SizedBox(height: 85),
    //           ],
    //         ),
    //       ),
    //     ),
    //   );

