import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class DiseasePrediction extends StatefulWidget {
  @override
  State<DiseasePrediction> createState() => _DiseasePredictionState();
}

class _DiseasePredictionState extends State<DiseasePrediction> {
  String? selectedCrop = 'Rice'; // Default to 'Rice'
  String? selectedIssue = 'Gallmidge'; // Default to 'Gallmidge'
  String? selectedYear = '2023'; // Default to '2023'
  String? selectedMonthInterval =
      '3 months onwards'; // Default to '3 months onwards'

  final List<String> crops = ['Rice', 'Cotton'];
  final Map<String, List<String>> cropIssues = {
    'Rice': ['Gallmidge', 'Greenleafhopper'],
    'Cotton': ['Americanbollworm', 'Pinkbollworm']
  };
  final List<String> years = ['2022', '2023', '2024'];
  final List<String> monthIntervals = [
    '3 months onwards',
    '6 months onwards',
    '9 months onwards'
  ];

  List<String> issuesForSelectedCrop = [];
  List<FlSpot> graphData = [];
  String inference = "Select crop and disease to see the inference.";

  // Function to generate graph data and inference based on selection
  void generateGraphData() {
    if (selectedCrop != null && selectedIssue != null) {
      setState(() {
        if (selectedCrop == 'Rice' && selectedIssue == 'Gallmidge') {
          graphData = [
            FlSpot(20, 30),
            FlSpot(25, 50),
            FlSpot(30, 70),
            FlSpot(35, 90),
            FlSpot(40, 100),
          ];
          inference =
              "For Gallmidge in Rice, the pest population increases steadily as the temperature rises, peaking at 40°C. Farmers should take preventive action in warm conditions.";
        } else if (selectedCrop == 'Rice' &&
            selectedIssue == 'Greenleafhopper') {
          graphData = [
            FlSpot(20, 40),
            FlSpot(25, 60),
            FlSpot(30, 80),
            FlSpot(35, 100),
            FlSpot(40, 120),
          ];
          inference =
              "For Greenleafhopper in Rice, pest population growth is rapid after 30°C, indicating a significant threat at higher temperatures.";
        } else if (selectedCrop == 'Cotton' &&
            selectedIssue == 'Americanbollworm') {
          graphData = [
            FlSpot(20, 50),
            FlSpot(25, 70),
            FlSpot(30, 90),
            FlSpot(35, 110),
            FlSpot(40, 130),
          ];
          inference =
              "For Americanbollworm in Cotton, pest infestation intensifies beyond 30°C. Immediate measures are recommended in hot weather.";
        } else if (selectedCrop == 'Cotton' &&
            selectedIssue == 'Pinkbollworm') {
          graphData = [
            FlSpot(20, 60),
            FlSpot(25, 80),
            FlSpot(30, 100),
            FlSpot(35, 120),
            FlSpot(40, 140),
          ];
          inference =
              "For Pinkbollworm in Cotton, the pest population shows consistent growth with temperature, becoming severe above 35°C.";
        } else {
          graphData = [];
          inference = "No data available for the selected crop and issue.";
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Disease Prediction",
          style: TextStyle(
              color: Colors.black,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              fontFamily: "Merriweather"),
        ),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Crop Dropdown
            DropdownButton<String>(
              value: selectedCrop,
              isExpanded: true,
              hint: Text('Crop'),
              onChanged: (value) {
                setState(() {
                  selectedCrop = value;
                  issuesForSelectedCrop = cropIssues[value!] ?? [];
                  selectedIssue = issuesForSelectedCrop.isNotEmpty
                      ? issuesForSelectedCrop[0]
                      : null; // Default to first issue
                  generateGraphData();
                });
              },
              items: crops.map((crop) {
                return DropdownMenuItem(value: crop, child: Text(crop));
              }).toList(),
            ),
            SizedBox(height: 16),

            // Disease Dropdown
            DropdownButton<String>(
              value: selectedIssue,
              isExpanded: true,
              hint: Text('Disease'),
              onChanged: (value) {
                setState(() {
                  selectedIssue = value;
                  generateGraphData();
                });
              },
              items: issuesForSelectedCrop.map((issue) {
                return DropdownMenuItem(value: issue, child: Text(issue));
              }).toList(),
            ),
            SizedBox(height: 16),

            // Year Dropdown
            DropdownButton<String>(
              value: selectedYear,
              isExpanded: true,
              hint: Text('Year'),
              onChanged: (value) {
                setState(() {
                  selectedYear = value;
                  generateGraphData();
                });
              },
              items: years.map((year) {
                return DropdownMenuItem(value: year, child: Text(year));
              }).toList(),
            ),
            SizedBox(height: 16),

            // Month Interval Dropdown
            DropdownButton<String>(
              value: selectedMonthInterval,
              isExpanded: true,
              hint: Text('Month Interval'),
              onChanged: (value) {
                setState(() {
                  selectedMonthInterval = value;
                  generateGraphData();
                });
              },
              items: monthIntervals.map((interval) {
                return DropdownMenuItem(value: interval, child: Text(interval));
              }).toList(),
            ),
            SizedBox(height: 16),

            // Graph Display
            Expanded(
              child: graphData.isEmpty
                  ? Center(child: Text('Select values to generate the graph'))
                  : LineChart(
                      LineChartData(
                        gridData: FlGridData(show: true),
                        titlesData: FlTitlesData(
                          leftTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: true),
                          ),
                          bottomTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: true),
                          ),
                        ),
                        borderData: FlBorderData(show: true),
                        lineBarsData: [
                          LineChartBarData(
                            spots: graphData,
                            isCurved: true,
                            color: Colors.blue,
                            barWidth: 4,
                            isStrokeCapRound: true,
                            belowBarData: BarAreaData(show: false),
                          ),
                        ],
                      ),
                    ),
            ),

            // Inference Text
            SizedBox(height: 16),
            Text(
              "Inference:",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 16),
            ),
            SizedBox(height: 8),
            Text(
              inference,
              style: TextStyle(color: Colors.black, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }
}
