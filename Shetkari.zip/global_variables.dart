class GlobalVariables {
  static String detectedCropDisease = '';

  int nitrogen = 80;
  int phosphorous = 70;
  int potassium = 90;
  int temperature = 30;
  int humidity = 85;
  int rainfall = 500;
  int soil_ph = 7;
}
